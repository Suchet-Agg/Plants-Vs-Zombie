package sample;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import javafx.scene.media.AudioClip;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class Controller_play implements Initializable {

    @FXML
    public ImageView pea;
    @FXML
    public ImageView zomb;
    @FXML
    public ImageView zomb1;
    @FXML
    public ImageView zombF;
    @FXML
    public ImageView sunt;
    @FXML
    public GridPane gridPane;
    @FXML
    public ImageView sunFlower;
    @FXML
    public ImageView peaShooter;
    @FXML
    public ImageView wallnut;
    @FXML
    public ImageView cherry;
    @FXML
    public AnchorPane overall;

    public FXMLLoader playController;


    public void hand1(ActionEvent actionEvent) {
        AudioClip audio = new AudioClip("file:src/music/buttonclick.wav");
        audio.play();
        try {
            Parent root = FXMLLoader.load( getClass().getClassLoader().getResource("pause_menu.fxml"));
            Main.stg.setScene(new Scene(root, 1280, 800));
            Main.stg.show();
        } catch(Exception e) {
            System.out.println("Error1");
        }
    }

    public void hand2(ActionEvent actionEvent) {
        AudioClip audio = new AudioClip("file:src/music/buttonclick.wav");
        audio.play();
    }

    public void moveZombie(Node zomb1 ,int time,int cycleCount,int setToX){
        TranslateTransition tt2;
        tt2 = new TranslateTransition();
        tt2.setNode(zomb1);
        tt2.setDuration(new Duration(time));
        tt2.setCycleCount(cycleCount);
        tt2.setCycleCount(Timeline.INDEFINITE);
        tt2.setToX(setToX);
    }

    public void movePea(Node pea, int time,int cycleCount,int setToX){
        TranslateTransition tt2;
        tt2 = new TranslateTransition();
        tt2.setNode(pea);
        tt2.setDuration(new Duration(time));
        tt2.setCycleCount(cycleCount);
        tt2.setCycleCount(Timeline.INDEFINITE);
        tt2.setToX(setToX);
    }

    public void moveSunflower(Node sunt,int time,int cycleCount,int setToX){
        TranslateTransition tt5;
        tt5 = new TranslateTransition();
        tt5.setNode(sunt);
        tt5.setDuration(new Duration(10000));
        tt5.setCycleCount(50);
        tt5.setCycleCount(Timeline.INDEFINITE);
        tt5.setToY(1000);
        tt5.play();
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        Main.a.pause();
        Main.b.play();

        gridPane.setOnDragOver(new EventHandler<DragEvent>() {
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                event.acceptTransferModes( TransferMode.COPY_OR_MOVE );
                event.consume();
            }
        });


        for(Node node: gridPane.getChildren()){
            node.setOnDragDropped(new EventHandler<DragEvent>() {
                @Override
                public void handle(DragEvent e)  {
                    Image files = e.getDragboard().getImage();
                    ImageView imageView =new ImageView();
                    imageView.setImage(files);
                    Integer cIndex = gridPane.getColumnIndex(node);
                    Integer rIndex = gridPane.getRowIndex(node);
                    int x = cIndex == null ? 0 : cIndex;
                    int y = rIndex == null ? 0 : rIndex;
                    gridPane.add(imageView,x,y);
                    e.consume();
                }
            });
        }

        peaShooter.setOnDragDetected(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                Dragboard db = peaShooter.startDragAndDrop(TransferMode.ANY);
                ClipboardContent content = new ClipboardContent();
                content.putImage(new Image("pea_shooter_dying.gif"));
                db.setContent(content);
                event.consume();
            }
        });

        wallnut.setOnDragDetected(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                Dragboard db = wallnut.startDragAndDrop(TransferMode.ANY);
                ClipboardContent content = new ClipboardContent();
                content.putImage(wallnut.getImage());
                db.setContent(content);
                event.consume();
            }
        });

        cherry.setOnDragDetected(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                Dragboard db = cherry.startDragAndDrop(TransferMode.ANY);
                ClipboardContent content = new ClipboardContent();
                content.putImage(cherry.getImage());
                db.setContent(content);
                event.consume();
            }
        });

        sunFlower.setOnDragDetected(new EventHandler<MouseEvent>() {

            public void handle(MouseEvent event) {
                Dragboard db = sunFlower.startDragAndDrop(TransferMode.ANY);
                ClipboardContent content = new ClipboardContent();
                content.putImage(new Image("sun_flower.gif"));
                db.setContent(content);
                event.consume();
            }
        });

    }
}