package sample;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.*;
import java.util.*;
import java.net.URL;


public class Main extends Application {
    public static MediaPlayer a;
    public static MediaPlayer b;
    static Controller_new NewController;
    static Controller_load LoadController;
    static Controller_pause PauseController;
    static Controller_play PlayController;
    static Controller SampleController;
    static Controller_level LevelController;

    public Main() throws IOException {
        URL resource = getClass().getResource("/music/Angry-Birds-Theme-Song.mp3");
        a = new MediaPlayer(new Media(resource.toString()));
        resource = getClass().getResource("/music/background.wav");
        b = new MediaPlayer(new Media(resource.toString()));
        a.setOnEndOfMedia(new Runnable() {
            @Override
            public void run() {
                a.seek(Duration.ZERO);
            }
        });
        b.setOnEndOfMedia(new Runnable() {
            @Override
            public void run() {
                b.seek(Duration.ZERO);
            }
        });

//        FXMLLoader l = new FXMLLoader(getClass().getResource("char_sel.fxml"));
//        Parent p1 = l.load();
//        NewController = (Controller_new) l.getController();
//
//        l = new FXMLLoader(getClass().getResource("load_char.fxml"));
//        Parent p2 = l.load();
//        LoadController = (Controller_load) l.getController();
//
//
//        l = new FXMLLoader(getClass().getResource("pause_menu.fxml"));
//        Parent p3 = l.load();
//        PauseController = (Controller_pause) l.getController();
//
//        l = new FXMLLoader(getClass().getResource("level_select.fxml"));
//        Parent p4 = l.load();
//        LevelController = (Controller_level) l.getController();
//
//        l = new FXMLLoader(getClass().getResource("lawn.fxml"));
//        Parent p5 = l.load();
//        PlayController = (Controller_play) l.getController();
//
//
//        l = new FXMLLoader(getClass().getResource("sample.fxml"));
//        Parent p6 = l.load();
//        SampleController = (Controller) l.getController();

    }

    static Stage stg;

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.stg = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Plants Vs. Zombies");
        primaryStage.setScene(new Scene(root, 1280, 800));
        primaryStage.show();
        URL resource = getClass().getResource("/music/Angry-Birds-Theme-Song.mp3");
        a.play();
    }

    public Stage getStg() {
        return stg;
    }

    public static void setStg(Stage stg) {
        Main.stg = stg;
    }

    public static void main(String[] args) throws IOException {
        Main m = new Main();
        Main.Backyard backyard = m.new Backyard();
        backyard.generate_suntoken();
        System.out.println(123);
        launch(args);
    }

//####################################################EXCEPTIONS#############################################################################

    class Sun_collected_exception extends Exception {

    }

    class Plant_placed_exception extends Exception {

    }

    class Zombie_and_Plant_on_same_tile extends Exception {

    }

    class Zombie_ate_plant extends Exception {

    }

    class Zombie_blown_by_plant extends Exception {

    }

    class Zombie_blocked_by_plant_exception extends Exception {

    }

    class Zombie_shot_by_plant_exception extends Exception {

    }

    class suntoken_gen_by_plant_exception extends Exception {

    }

    class Zombie_died_exception extends Exception {

    }

    class Plant_purchased_exception extends Exception {

    }

    class lawnmower_activated_exception extends Exception {

    }

    class zombie_reached_house_exception extends Exception {

    }

    class level_cleared_exception extends Exception {

    }

    class mission_failed_exception extends Exception {

    }

    class game_won_exception extends Exception {

    }


//###############################################CONTROL##################################################################################################

    interface Control {
        public void control();
    }

    class Scorecard implements Control {
        private ArrayList<Plant> available_plants;
        private int num_tokens;
        private int score;
        private ImageView scoreboard;
        private Image sc;

        @Override
        public void control() {

        }

        //ASMIT -  ADD PATH TO IMAGES in image and imageview
        public Scorecard() {
            this.score = 0;
            this.num_tokens = 0;
            this.available_plants = new ArrayList<Plant>();

        }

        //
//    public void Display_score(){
//;
//    }
        public ArrayList<Plant> getAvailable_plants() {
            return available_plants;
        }

        public int getScore() {
            return score;
        }

        public void increase_score() {
            this.score += 50;
            this.num_tokens++;
        }
    }

    class Inventory implements Control {
        private ArrayList<Plant> purchased_plants;
        private int quantity;
        private ImageView inventroy;
        private Image inv;

        @Override
        public void control() {

        }

        //ASMIT -  ADD PATH TO IMAGES in image and imageview
        public Inventory() {
            purchased_plants = new ArrayList<Plant>();
            quantity = 0;


        }


        public ArrayList<Plant> getPurchased_plants() {
            return purchased_plants;
        }

        public void set_quantity(int q, Plant p) {

        }

        public void purchase_Plant(Plant plant) {
            purchased_plants.add(plant);

        }
    }

    class ProgressBar implements Control {
        int progress;
        int level;
        private ImageView prog;
        private Image pr;
        private ImageView progressBar;
        private Image prb;

        public ProgressBar() {
            progress = 0;
        }

        @Override
        public void control() {
            ;
        }

        public int getLevel() {
            return level;
        }

        public void setLevel(int level) {
            this.level = level;
        }

        public int getProgress() {
            return progress;
        }

        public void setProgress(int progress) {
            this.progress = progress;
        }
    }

    class Database implements Control {
        private String save_game_filename;

        @Override
        public void control() {

        }

        public String getSave_game_filename() {
            return save_game_filename;
        }

        public void setSave_game_filename(String save_game_filename) {
            this.save_game_filename = save_game_filename;
        }

        public void serialize(PlantsvsZombies game) throws IOException {
            ObjectOutputStream out = null;
            try {
                out = new ObjectOutputStream(new FileOutputStream(save_game_filename));
                out.writeObject(game);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.close();
                }
            }
        }

        public void deserialize(PlantsvsZombies game) throws IOException, ClassNotFoundException {
            ObjectInputStream in = null;
            try {
                in = new ObjectInputStream(new FileInputStream(save_game_filename));
                PlantsvsZombies newGame = (PlantsvsZombies) in.readObject();
            } finally {
                in.close();
            }
        }
    }


    abstract class Menu implements Control {
        @Override
        public void control() {

        }

        public boolean is_Active() {
            return false;
        }

        abstract public void Display();
    }

    class MainMenu extends Menu {
        @Override
        public void Display() {

        }

        public void PlayGame() {

        }

        public void LoadGame() {

        }
    }

    class ResumeMenu extends Menu {
        @Override
        public void Display() {

        }

        public void resume() {

        }

        public void save_and_exit() {

        }
    }

    class IngameMenu extends Menu {
        @Override
        public void Display() {

        }

        public void Continue() {

        }

        public void save_and_exit() {

        }
    }

//#####################################################33PLANTSVSZOMBIES########################################################

    class PlantsvsZombies implements Serializable {
        private User newUser;
        private Backyard newBckyard;

        public PlantsvsZombies() {
            ;
        }

        public void playGame() {

        }

        public void loginPlayer(String Playername) {

        }

        public void pause() {

        }

        public void save() {

        }

        public void Load() {

        }

        public void Quit() {

        }

        public void DisplayMainMenu() {

        }

        public void DisplayResumeMenu() {

        }

        public void DisplayIngameMenu() {

        }

        public void MovePlayerToNextLevel() {

        }

        public void ResetGame() {

        }

        public void GameWon() {

        }

        public void GameOver() {

        }
    }

    class User implements Serializable {
        private String Name;
        private boolean isLoggedin;

        public User(String name) {
            Name = name;
            isLoggedin = false;
        }


        //ASMIT
        public void login() {

        }

        public String getName() {
            return Name;
        }

        public boolean isLoggedin() {
            return isLoggedin;
        }
    }

    class Player extends User implements Serializable {
        private Level curr_level;
        private Inventory inventory;
        private int score;
        private Scorecard available_Plant;

        public Player(String name) {
            super(name);
        }

        public Level getCurr_level() {
            return curr_level;
        }

        public Inventory getInventory() {
            return inventory;
        }

        public int getScore() {
            return score;
        }

        public Scorecard getAvailable_Plant() {
            return available_Plant;
        }

        public void level_up() {
            if (curr_level.isFinished()) {
                this.curr_level.setCurr_level(this.curr_level.getCurr_level() + 1);
            }
        }

        public void PurchasePlant(Plant plant) {
            inventory.purchase_Plant(plant);
        }
//    public void PlacePlant(){
//
//    }
//    public void CollectSun(){
//
//    }


        public void play() {

        }

        public void pause() {

        }

    }


    interface world {
        void initialise();
    }


    class Tile implements world, Serializable {
        private Plant curr_plant;
        private Zombie curr_zombie;
        private Position position;
        private boolean isempty;

        public Tile() {
            isempty = true;
        }

        @Override
        public void initialise() {
            curr_plant = null;
            curr_zombie = null;
        }

        public Tile(Position pos) {
            this.position = pos;
        }

        public boolean has_plant() {
            if (curr_plant != null) {
                return true;
            }
            return false;
        }

        public boolean has_zombie() {
            if (curr_zombie != null) {
                return true;
            }
            return false;
        }

        public Plant getCurr_plant() {
            return curr_plant;
        }

        public Zombie getCurr_zombie() {
            return curr_zombie;
        }

        public Position getPosition() {
            return position;
        }

        public void setCurr_plant(Plant curr_plant) {
            if (isempty) {
                this.curr_plant = curr_plant;
                isempty = false;
            }
        }

        public void setCurr_zombie(Zombie curr_zombie) {
            this.curr_zombie = curr_zombie;
        }
    }


    class Lawn implements world, Serializable {
        private ArrayList<Tile> Tiles;
        private Level curr_level;
        private ArrayList<LawnMower> mowers;

        public Lawn() {
            Tiles = new ArrayList<Tile>();
            curr_level = new Level(1);
            mowers = new ArrayList<LawnMower>();
            initialise();
        }

        @Override
        public void initialise() {
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 9; j++) {
                    Tiles.add(new Tile(new Position(i, j)));
                }
            }
            for (int i = 0; i < 5; i++) {
                mowers.add(new LawnMower(new Position(i, 0)));
            }

        }

        public Level getCurr_level() {
            return curr_level;
        }

        public void setCurr_level(Level curr_level) {
            this.curr_level = curr_level;
        }
    }


    class Backyard implements world, Serializable {
        private Lawn curr_lawn;
        public Lawn getCurr_lawn() {
            return curr_lawn;
        }

        public Backyard() {
            System.out.println(123123);
            initialise();
        }

        @Override
        public void initialise() {
            curr_lawn = new Lawn();

        }

        //    public void display_backyard(){
//
//    }
        public void generate_Zombie() {
            if (curr_lawn.getCurr_level().getCurr_level() == 1) {

            } else if (curr_lawn.getCurr_level().getCurr_level() == 2) {

            } else if (curr_lawn.getCurr_level().getCurr_level() == 3) {

            } else if (curr_lawn.getCurr_level().getCurr_level() == 4) {

            } else if (curr_lawn.getCurr_level().getCurr_level() == 5) {

            }
        }

        public void generate_suntoken() {
            Timer timer = new Timer();
            int min = 0;
            int max = 1200;
            timer.schedule(new TimerTask() {
                public void run() {
                    SunToken s = new SunToken();
                    ImageView sun = s.getSuntoken();
                    sun.setY((Math.random() * ((max - min) + 1)) + min);
                    s.setSuntoken(sun);
                    try {
                        lawn_play.getPlayController().overall.getChildren().add(s.getSuntoken());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }, 0, 4 * 1000);
        }

        public void launch_lawnmower() {

        }
    }


    class Level implements world, Serializable {
        private int curr_level;
        ProgressBar progressBar;

        @Override
        public void initialise() {
            ;
        }

        public boolean isFinished() {
            if (progressBar.getProgress() == 100) {
                progressBar.setLevel(progressBar.getLevel() + 1);
                progressBar.setProgress(0);
                return true;
            }
            return false;
        }

        public Level(int curr_level) {
            this.curr_level = curr_level;
            progressBar = new ProgressBar();
        }

        public int getCurr_level() {
            return curr_level;
        }

        public void setCurr_level(int curr_level) {
            this.curr_level = curr_level;
        }
    }

    class Position implements world, Serializable {
        private int x;
        private int y;

        public Position(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public void initialise() {
        }

        public int getY() {
            return y;
        }

        public int getX() {
            return x;
        }

        public void set_pos(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    interface Character extends world {
        public void Act();
    }

    interface Friend extends Character {
        public void Use();
    }

    interface Foe extends Character {
        public void Eat(Plant p);
    }

    class Plant implements Friend, Serializable {
        protected int health;
        protected Position pos;
        protected boolean plant_eaten;
        protected boolean is_available;
        protected int time_before_buy;
        private ImageView plant;
        private Image plt;

        @Override
        public void initialise() {

        }

        @Override
        public void Use() {

        }

        @Override
        public void Act() {

        }

        public void place(Position p) {

        }

        public void setHealth(int health) {
            this.health = health;
        }

        public void setPos(Position pos) {
            this.pos = pos;
        }

    }

    class Bullet implements Friend, Serializable {
        private float vel;
        private Position pos;
        private boolean hit_zombie;
        private boolean out_of_screen;
        private ImageView peas;
        private Image p;

        //ASMIT -  ADD PATH TO IMAGES in image and imageview
        public Bullet() {
            //Change
            vel = 5;
            pos = new Position(0, 0);
            hit_zombie = false;
            out_of_screen = true;
        }

        @Override
        public void initialise() {

        }

        @Override
        public void Use() {

        }

        @Override
        public void Act() {

        }

        public float getVel() {
            return vel;
        }

        public Position getPos() {
            return pos;
        }

        public void setVel(float vel) {
            this.vel = vel;
        }

        public void setPos(Position pos) {
            this.pos = pos;
        }

        public void hit_zombie() {

//        public void collision(ImageView a ,Zombie z) {
//            if (a.getBoundsInLocal().intersects(b.getBoundsInLocal())) {
//                b.setY(-100);
//                score++;
//            }
//        }

        }

        public void out_of_screen() {

        }
    }

    class Shooter extends Plant {
        protected Bullet pea;
        protected int interval_shot;

        public void shoot() {
            //ASMIT add path to pea shoot sound
            AudioClip audio = new AudioClip("");
            audio.play();

        }
    }

    class Peashooter extends Shooter {
        private int num_peas_fired = 1;

        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
        public Peashooter() {

        }
    }

    class Threepeater extends Shooter {
        private int num_peas_fired = 3;

        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
    }

    class Barrier extends Plant {
        protected int extra_health;

        public void Protect() {

        }
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
    }

    class SunPlant extends Plant {
        protected int time_bw_suns;

        public void generate_sun() {
            //ASMIT add path to sun sound
            AudioClip audio = new AudioClip("");
            audio.play();

        }
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
    }

    class BombPlant extends Plant {
        protected boolean has_exploded;
        protected boolean is_near_zombie;

        public void explode() {
            //ASMIT add path to bomb sound
            AudioClip audio = new AudioClip("");
            audio.play();
        }
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
    }

    class PotatoMine extends BombPlant {
        private int activation_time = 14;
        private int area = 1;
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
    }

    class Cherry_Bomb extends BombPlant {
        private double activation_time = 1.2;
        private int area = 9;
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
    }


    class SunToken implements Friend, Serializable {
        private Position pos;
        private float vel;
        private int points;
        private ImageView suntoken;
        private Image sun;

        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
        public SunToken() {
            sun = new Image("sun.gif");
            suntoken = new ImageView(sun);
            suntoken.setOnMouseClicked(new EventHandler<MouseEvent>() {
                public void handle(MouseEvent event) {
                    try {
                        lawn_play.getPlayController().overall.getChildren().remove(suntoken);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println(1);
                }
            });
        }

        public void move() throws IOException {
            lawn_play.getPlayController().moveSunflower(suntoken, 500, 1, -1000);
        }

        @Override
        public void initialise() {

        }

        @Override
        public void Use() {

        }

        @Override
        public void Act() {

        }

        public ImageView getSuntoken() {
            return suntoken;
        }

        public void setSuntoken(ImageView suntoken) {
            this.suntoken = suntoken;
        }

        public Position getPos() {
            return pos;
        }

        public float getVel() {
            return vel;
        }

        public int getPoints() {
            return points;
        }

    }


    class LawnMower implements Friend, Serializable {
        private boolean is_avialable;
        private boolean has_zombie_reached;
        private Position p;
        private ImageView mowers;
        private Image mow;

        public LawnMower(Position p) {
            this.p = p;
        }
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot

        @Override
        public void Act() {

        }

        @Override
        public void Use() {

        }

        @Override
        public void initialise() {

        }

        public void run_lawnmower() {
            //ASMIT add path to lawnmower sound
            AudioClip audio = new AudioClip("");
            audio.play();

        }
    }

    class Zombie implements Foe, Serializable {
        protected int health;
        protected float vel;
        protected Position pos;
        protected boolean is_dead;
        protected boolean has_reached;
        protected int zombie_count;
        private ImageView zombie;
        private Image zomb;

        @Override
        public void initialise() {

        }

        @Override
        public void Eat(Plant p) {

        }

        @Override
        public void Act() {

        }

        public void move() {

//        TranslateTransition tt3;
//        tt3 = new TranslateTransition();
//        tt3.setNode(zomb);
//        tt3.setDuration(new Duration(15000));
//        tt3.setCycleCount(50);
//        tt3.setCycleCount(Timeline.INDEFINITE);
//        tt3.setToX(-1000);
//        tt3.play();


            //ASMIT add path to zombie sound
            Timer timer = new Timer();
            AudioClip audio = new AudioClip("");
            timer.schedule(new TimerTask() {
                public void run() {
                    if (!is_dead) {
                        audio.play();
                    }
                }
            }, 0, 4 * 1000);

        }

        public boolean isHas_reached() {
            return has_reached;
        }

        public boolean isIs_dead() {
            return is_dead;
        }

        public void setPos(Position pos) {
            this.pos = pos;
        }

        public void setVel(float vel) {
            this.vel = vel;
        }

        public void setHealth(int health) {
            this.health = health;
        }

        public int getZombie_count() {
            return zombie_count;
        }

        public Position getPos() {
            return pos;
        }

        public float getVel() {
            return vel;
        }

        public int getHealth() {
            return health;
        }
    }

    class ConeHead extends Zombie {
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot
        private int extra_health;

        public void attack() {

        }

        public void defend() {

        }
    }

    class vanillaZombie extends Zombie {
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot


    }

    class FootballZombie extends Zombie {
        //ASMIT -  ADD PATH TO IMAGES in image and imageview fill contrucot

        private int extra_health;
        private int extra_attack;

        public void attack() {

        }

        public void defend() {

        }
    }
}
